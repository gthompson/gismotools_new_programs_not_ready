classdef CreationInfo
    % CreationInfo
    properties
        agency_id;
        author;
        creation_time;
    end
    methods
        function obj = CreationInfo(varargin)
            % create an id that increments with each object created
            persistent agency_id;
            if isempty(agency_id)
                agency_id = 1;
            else
                agency_id = agency_id + 1;
            end     
            % Parse required, optional and param-value pair arguments,
            % set default values, and add validation conditions
            p = inputParser;
            p.addOptional('agency_id', num2str(agency_id), @isstr);
            p.addOptional('author', '', @isstr);
            p.addOptional('creation_time', now, @(t) t>0 & t<now+1);
            p.parse(varargin{:})
            obj.agency_id = p.Results.agency_id;
            obj.author = p.Results.author;
            obj.creation_time = p.Results.creation_time;            
        end
        function str = print(obj)
            str = sprintf('CreationInfo:\n\tagency_id=%s\n\tauthor=%s\n\tcreation_time=%s\n', ...
                obj.agency_id, obj.author, datestr(obj.creation_time)); 
        end
    end
end