classdef Pick
    % Pick
    % see http://docs.obspy.org/packages/autogen/obspy.core.event.Pick.html
    properties
        time; % onset time as datenum
        %time_errors; % seconds
        scnl; % scnlobject
        %filter; % filterobject
        %method = ''; % software algorithm or author
        %horizontal_slowness;
        %horizontal_slowness_errors;
        %backazimuth;
        %backazimuth_errors;
        %slowness_method;
        onset; % = ''; % "emergent", "impulsive", "questionable"
        phase_hint; % = ''; % phase identified by the picker
        polarity; % = ''; 'positive', 'negative', 'undecidable'
        evaluation_mode; % = ''; % 'manual', 'automatic'
        evaluation_status = ''; % 'preliminary', 'confirmed', 'reviewed', 'final', 'reported'
        comments; % = []; % list of Comment
        creation_info; % = CreationInfo();
    end
    methods
        function obj = Pick(time, scnl, varargin)
            % Parse required, optional and param-value pair arguments,
            % set default values, and add validation conditions
            p = inputParser;
            p.addRequired('time', @isnumeric);
            p.addRequired('scnl', scnlobject(), @(s) strcmp(class(s), 'scnlobject'));
            p.addParamValue('onset', '', @isstr );
            p.addParamValue('phase_hint', '', @isstr );    
            p.addParamValue('polarity', '', @isstr );
            p.addParamValue('evaluation_mode', '', @isstr );    
            p.addParamValue('evaluation_status', '', @isstr );
            p.addParamValue('comments', [Comment('')], @(c) strcmp(class(c), 'Comment') );
            p.addParamValue('creation_info', CreationInfo(), @(c) strcmp(class(c), 'CreationInfo') )
            p.parse(time, scnl, varargin{:});
            obj.time = p.Results.time;
            obj.scnl = p.Results.scnl;
            obj.onset = p.Results.onset;
            obj.phase_hint = p.Results.phase_hint;
            obj.polarity = p.Results.polarity;
            obj.evaluation_mode = p.Results.evaluation_mode;
            obj.evaluation_status = p.Results.evaluation_status;
            obj.comments = p.Results.comments;
            obj.creation_info = p.Results.creation_info;
        end
        function print(obj)
        end
    end
end