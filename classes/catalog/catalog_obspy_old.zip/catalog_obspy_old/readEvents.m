function cobj = readEvents(data_source, varargin)
%READEVENTS: Load events from various catalog data sources into a Catalog
% object.
%
%% USAGE
%
%   cobj = readEvents(data_source, 'param1', value1, 'param2', value2 ...)
%             loads a seismic event catalog into a GISMO/Catalog object.
%             data_source is a method by which the source catalog is
%             retrieved, or format in which the source catalog is stored.
%             This may be followed by named parameter-value pairs. Allowed
%             parameter-value pairs vary according to data_source.
%            
%             The output cobj is a Catalog object, which itself may contain
%             a hierarchy of Event, Origin and Magnitude objects. Each of
%             these classes is styled after classes available in ObsPy. See
%             http://docs.obspy.org/packages/autogen/obspy.core.event.html
%             for details.
%% MODES
%
%   Data can be loaded in "fast" or "normal" mode (default is "normal").
%   In normal mode, a Catalog object is constructed consisting of Event,
%   Origin and Magnitude objects (and perhaps others as this is expanded
%   to describe a catalog in more detail).
%   In "fast" mode, a Catalog_lite object is constructed. It has no
%   underlying Event, Origin or Magnitude objects.
%   Catalog and Catalog_lite have a lot of common functionality as they
%   derive from the same superclass, Catalog_base.
%   To load data in "fast" mode, include the additional parameter-value
%   pair:
%       readEvents(..., 'mode', 'fast')
%
%% LOADING FROM DATASCOPE (ANTELOPE) DATABASES
%
%   cobj = readEvents('datascope', 'dbpath', path_to_database)
%             loads events, origins and magnitudes from a Datascope
%             (Antelope) database given by the dbpath parameter-value. As a
%             minimum, the database must have an origin table.
%
%   If the database is stored in daily volumes, e.g. foo/bar_YYYY_MM_DD, 
%   rather than a single database use the 'archiveformat'
%   name/value pair, e.g.
%
%   cobj = readEvents('datascope', 'dbpath', 'foo/bar', ...
%             'archiveformat','daily');
%
%   For monthly volumes, e.g. foo/bar_YYYY_MM, set 'archiveformat' to
%   'monthly':
%
%   cobj = readEvents('datascope', 'dbpath', 'foo/bar', ...
%             'archiveformat','monthly');
%
%   cobj = readEvents('datascope', 'dbpath', path_to_database, ...
%             'dbeval', dbeval_expression)
%             will subset the database given a valid datascope subset
%             expression.
%
%   If the dbeval parameter name/value pair is omitted, a dbeval expression 
%   can also be formed from other name/value pairs. These are:
%       PARAMETER  VALUE
%       'snum'     a datenum denoting the minimum origin time
%       'enum'     a datenum denoting the maximum origin time
%       'minmag'   the minimum magnitude
%       'mindepth' the minimum depth (in km)
%       'maxdepth' the maximum depth (in km)
%       'region'   a 4-element vector: [minlon maxlon minlat maxlat]
%
%% LOADING FROM FDSN DATA SOURCES
%   cobj = readEvents('irisfetch', 'param1', value1, 'param2', value2 ...)
%             loads events, origins and magnitudes from IRIS-DMC or other
%             FSDN data sources via irisFetch.m. The allowed parameter-value 
%             pairs are those allowed by irisFetch.m. 
%
%% READING FROM A SEISAN-DERIVED DAT FILE
% 
%   cobj = readEvents('aef', 'datapath', datapath) 
%     will attempt to load all Seisan-derived AEF summary files in the 
%     directory specified by datapath.
% 
%     To subset the data, use parameter name/value pairs (snum, enum, 
%     minmag, mindepth, maxdepth, region). 
% 
%% EXAMPLES
%
%   (1) Import all events from the demo database
%         % get path to demo database
%         dbpath = demodb('avo');
%         % read events from database
%         cobj = readEvents('datascope', 'dbpath', dbpath);
%
%   (2) As previous example, but use a subset expression also. Here we
%       subset for origins within 15 km of Redoubt volcano:
%         cobj = readEvents('datascope', 'dbpath', dbpath, ...
%         'dbeval', 'deg2km(distance(lat, lon, 60.4853, -152.7431))<15.0');
%
%   (3) Read all magnitude>7 events from IRIS DMC via irisFetch.m:
%         cobj = readEvents('irisfetch', 'MinimumMagnitude', 7.0);
%
%   (4) Read all events within 20 km of Redoubt volcano from IRIS DMC:
%         cobj = readEvents('irisfetch', ...
%         'radialcoordinates', [60.4853 -152.7431 deg2rad(20)]); 
%
%      Identical results could be obtained with:
% 
%      cobj = Catalog_old(dbroot, 'antelope', 'dbeval','time >= "2009/3/20" && time <= "2009/3/23" && lon >= -153.0 && lon <= -152.2 && lat >= 60.3 && lat <= 60.7')
% 
%   (5) Read Alaska Earthquake Center events greater than M=4.0 in 2009
%       within rectangular region lat = 55 to 65, lon = -170 to -135 from
%       the "Total" database of all regional earthquakes in Alaska:
%         cobj = readEvents('datascope', ...
%                'dbpath', '/Seis/catalogs/aeic/Total/Total', ...
%                'snum', datenum(2009,1,1), ... 
%                'enum', datenum(2010,1,1), ...
%                'minmag', 4.0, ...
%                'region', [-170.0 -135.0 55.0 65.0] ...
%         );
%
%   (6) As 5, but use a dbeval expression instead:
%         cobj = readEvents('datascope', ...
%                'dbpath', '/Seis/catalogs/aeic/Total/Total', ...
%                'dbeval', 'time > "2009/1/1" & time < "2010/1/1"' ...
%                ' & ml > 4 & lon > -170.0 & lon < -135.0' ...
%                ' & lat > 55.0 & lat < 65.0' ...
%         );
%   (7) Reading MVO data from station MBWH for all of year 2000:
%         cobj = readEvents('aef', 'datapath', fullfile(MVO_DATA, 'mbwh_catalog'), ...
%                'snum', datenum(2000,1,1), ...
%                'enum', datenum(2000,12,31,23,59,59) ...
%         );
% 
%% See also CATALOG, EVENT, MAGNITUDE, IRISFETCH. CATALOG_COOKBOOK
%
% Author: Glenn Thompson (glennthompson1971@gmail.com)
% $Date: $
% $Revision: $
disp(varargin)
    switch lower(data_source)
        case {'css3.0','antelope', 'datascope'}
            % url is called dbpath within load_datascope_events
            cobj = load_datascope_events(varargin{:});
        case 'irisfetch'
            ev = irisFetch.Events(varargin{:});
            cobj = convert_irisFetch_to_Catalog(ev);
        case 'sfiles'
            cobj = load_sfiles(varargin{:});
        case 'aef'
            cobj = load_aef(varargin{:});
        otherwise
            cobj = NaN;
            fprintf('format %s unknown\n\n',data_source);
    end
end


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function cobj = load_datascope_events(varargin)            
disp(varargin)
    if ~admin.antelope_exists
        error('This function requires the Antelope toolbox for Matlab'); 
        return;
    end

    % Process input arguments
    p = inputParser;
    p.addParamValue('dbpath', @isstr);
    p.addParamValue('dbeval', '', @isstr);
    p.addParamValue('archiveformat', 'single file', @isstr);
    p.addParamValue('snum', [], @isnumeric);  
    p.addParamValue('enum', [], @isnumeric);
    p.addParamValue('minmag', [], @isnumeric);
    p.addParamValue('region', [], @isnumeric);
    p.addParamValue('subclass', '*', @ischar);
    p.addParamValue('mindepth', [], @isnumeric);
    p.addParamValue('maxdepth', [], @isnumeric);
    p.addParamValue('mode', 'normal', @isstr);
    p.parse(varargin{:});
    dbpath = p.Results.dbpath;
    dbeval_expression = p.Results.dbeval; % dbeval is the name for user to use
    snum = p.Results.snum;
    enum = p.Results.enum;
    minmag = p.Results.minmag;
    region = p.Results.region;
    mindepth = p.Results.mindepth;
    maxdepth = p.Results.maxdepth;
    archiveformat = p.Results.archiveformat;
    %[dbeval, archiveformat, snum, enum, minmag, region, subclass, mindepth, ...
    %    maxdepth] = matlab_extensions.process_options(varargin, 'dbeval', '', ...
    %    'archiveformat', '', 'snum', [], 'enum', [], 'minmag', [], 'region', [], ...
    %    'subclass', '*', 'mindepth', [], 'maxdepth', []); 

    % Create a dbeval expression if not already set.
    if isempty(dbeval_expression)
        if nargin > 2
            expr = '';
            if ~isempty(snum) & isnumeric(snum)
                expr = sprintf('%s && time >= %f',expr,datenum2epoch(snum));
            end 
            if ~isempty(enum) & isnumeric(enum)
                expr = sprintf('%s && time <= %f',expr,datenum2epoch(enum));
            end
            if ~isempty(minmag) & isnumeric(minmag)
                expr = sprintf('%s && (ml >= %f || mb >= %f || ms >= %f)',expr,minmag,minmag,minmag);
            end
            if ~isempty(region) & isnumeric(region)
                leftlon = region(1); rightlon=region(2); lowerlat=region(3); upperlat=region(4);
                expr = sprintf('%s && (lat >= %f && lat <= %f && lon >= %f && lon <= %f)',expr,lowerlat, upperlat, leftlon, rightlon);
            end
            if ~isempty(mindepth) & isnumeric(mindepth)
                expr = sprintf('%s && (depth >= %f)', expr,mindepth); 
            end
            if ~isempty(maxdepth) & isnumeric(maxdepth)
                expr = sprintf('%s && (depth <= %f)', expr,maxdepth); 
            end
            dbeval_expression = expr(4:end);
            clear expr
        end
    end
    
    % BUILD DBNAMELIST
    dbpathlist = {};
    
    if strcmp(archiveformat,'single file') % Just 1 entry
        dbpathlist = {dbpath};   
    else
        if isempty(snum) || isempty(enum)
            disp(sprintf('Failure: you must set values for \"snum\" and \"enum\" parameters when \"archiveformat\" is set to \"daily\" or \"monthly\"'));
            return;
        end
        if strcmp(archiveformat,'daily')
            for dnum=floor(snum):floor(enum-1/1440)
                dbpathfull = sprintf('%s_%s',dbpath,datestr(dnum, 'yyyy_mm_dd'));
                if exist(sprintf('%s.origin',dbpathfull),'file')
                    dbpathlist{end+1} = dbpathfull; % Add here
                else
                    fprintf('%s.origin not found\n',dbpath);
                end
            end
        elseif strcmp(archiveformat,'monthly')
            for yyyy=dnum2year(snum):1:dnum2year(enum)
                for mm=dnum2month(snum):1:dnum2month(enum)
                    dnum = datenum(yyyy,mm,1);
                    dbpathfull = sprintf('%s%04d_%02d',dbpath,yyyy,mm);
                    if exist(sprintf('%s.origin',dbpath),'file') 
                        dbpathlist{end+1} = dbpathfull; % Add here
                    else
                        fprintf('%s.origin not found\n',dbpath);
                    end
                end
            end
        end
    end
    
    % LOAD FROM DBNAMELIST
    % Initialize to empty
    [lat, lon, depth, dnum, time, evid, orid, nass, mag, ml, mb, ms, etype, auth] = deal([]);
    subclass = '';
    for dbpathitem = dbpathlist
        % Load vectors
        [lon0, lat0, depth0, dnum0, evid0, orid0, nass0, mag0, mb0, ml0, ms0, subclass0, auth0] = dbloadprefors(dbpathitem, dbeval_expression);
        if length(lon0) == length(mag0)
            % Concatentate vectors
            lon   = cat(1, lon,   lon0);
            lat   = cat(1, lat,   lat0);
            depth = cat(1, depth, depth0);
            dnum  = cat(1, dnum,  dnum0);
            evid  = cat(1, evid,  evid0);
            orid  = cat(1, orid,  orid0);
            nass  = cat(1, nass,  nass0);
            mag   = cat(1, mag,   mag0);
            mb   = cat(1, mb,   mb0);
            ml   = cat(1, ml,   ml0);
            ms   = cat(1, ms,   ms0);
            subclass  = cat(2, subclass, subclass0);
            auth = cat(1,  auth, auth0);
        end
    end
    mag(mag<-3.0)=NaN;
    if strcmp(p.Results.mode, 'normal')
        %%% SLOW MODE %%%
        % Create an Event object for each longitude in the list
        event_list = [];
        for i=1:length(lon) % Loop over each element in vector
            magnitude_obj = Magnitude(mag(i));
            origin_obj = Origin(dnum(i), lon(i), lat(i), depth(i), ...
                    'origin_id', num2str(orid(i)) ...
                );
            event_list = [ ...
                event_list ...
                Event( ...
                    [origin_obj], ...
                    'event_type', subclass(i), ...
                    'magnitudes', [magnitude_obj], ...
                    'event_id', num2str(evid(i)) ...
                    ) ...
                ];
        end

        % CREATE CATALOG OBJECT
        cobj = ...
            Catalog( ...
                event_list, ...
                'comments', [Comment(sprintf('Loaded at %s',datestr(now)))], ...
                'creation_info', CreationInfo('', mfilename, utnow) ...
            );

    elseif strcmp(p.Results.mode, 'fast')
        %%% FAST MODE %%%
        cobj = Catalog(lat, lon, depth, dnum, mag, subclass);
    end
    cobj = cobj.addfield('data_source', 'datascope');
    cobj = cobj.addfield('dbpath', dbpath);
    cobj = cobj.addfield('archiveformat', archiveformat);
    
    % SUBSET THE DATA BASED ON ETYPE - COULD I NOT DO THIS IS DBEVAL with
    % '& etype=="r"'
%     if exist('subclass', 'var')
%         if ~strcmp(subclass, '*')
%             index = findstr(cobj.etype, subclass);
%             cobj.lat = cobj.lat(index);
%             cobj.lon = cobj.lon(index);
%             cobj.depth = cobj.depth(index);
%             cobj.dnum = cobj.dnum(index);
%             cobj.evid = cobj.evid(index);
%             cobj.orid = cobj.orid(index);
%             cobj.nass = cobj.nass(index);
%             cobj.mag = cobj.mag(index);
%             cobj.etype = cobj.etype(index);
%             cobj.auth = {};
%         end
%     end
    
end

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [lon, lat, depth, dnum, evid, orid, nass, mag, mb, ml, ms, etype, auth] = dbloadprefors(dbpath, dbeval_expression)

    numorigins = 0;
    [lat, lon, depth, dnum, time, evid, orid, nass, mag, ml, mb, ms, etype, auth] = deal([]);
    if iscell(dbpath)
        dbpath = dbpath{1};
    end
    debug.print_debug(sprintf('Loading data from %s',dbpath),3);

    ORIGIN_TABLE_PRESENT = dbtable_present(dbpath, 'origin');

    if (ORIGIN_TABLE_PRESENT)
        db = dblookup_table(dbopen(dbpath, 'r'), 'origin');
        numorigins = dbquery(db,'dbRECORD_COUNT');
        debug.print_debug(sprintf('Got %d records from %s.origin',numorigins,dbpath),1);
        if numorigins > 0
            EVENT_TABLE_PRESENT = dbtable_present(dbpath, 'event');           
            if (EVENT_TABLE_PRESENT)
                db = dbjoin(db, dblookup_table(db, 'event') );
                numorigins = dbquery(db,'dbRECORD_COUNT');
                debug.print_debug(sprintf('Got %d records after joining event with %s.origin',numorigins,dbpath),1);
                if numorigins > 0
                    db = dbsubset(db, 'orid == prefor');
                    numorigins = dbquery(db,'dbRECORD_COUNT');
                    debug.print_debug(sprintf('Got %d records after subsetting with orid==prefor',numorigins),1);
                    if numorigins > 0
                        db = dbsort(db, 'time');
                    else
                        % got no origins after subsetting for prefors - already reported
                        debug.print_debug(sprintf('%d records after subsetting with orid==prefor',numorigins),0);
                        return
                    end
                else
                    % got no origins after joining event to origin table - already reported
                    debug.print_debug(sprintf('%d records after joining event table with origin table',numorigins),0);
                    return
                end
            else
                debug.print_debug('No event table found, so will use all origins from origin table, not just prefors',0);
            end
        else
            % got no origins after opening origin table - already reported
            debug.print_debug(sprintf('origin table has %d records',numorigins),0);
            return
        end
    else
        debug.print_debug('no origin table found',0);
        return
    end

    numorigins = dbquery(db,'dbRECORD_COUNT');
    debug.print_debug(sprintf('Got %d prefors prior to subsetting',numorigins),2);

    % Do the subsetting
    if ~isempty(dbeval_expression)
        db = dbsubset(db, dbeval_expression);
        numorigins = dbquery(db,'dbRECORD_COUNT');
        debug.print_debug(sprintf('Got %d prefors after subsetting',numorigins),2);
    end

    if numorigins>0
        if EVENT_TABLE_PRESENT
            [lat, lon, depth, time, evid, orid, nass, ml, mb, ms, auth] = dbgetv(db,'lat', 'lon', 'depth', 'time', 'evid', 'orid', 'nass', 'ml', 'mb', 'ms', 'auth');
        else
            [lat, lon, depth, time, orid, nass, ml, mb, ms, auth] = dbgetv(db,'lat', 'lon', 'depth', 'time', 'orid', 'nass', 'ml', 'mb', 'ms', 'auth');  
            disp('Setting evid == orid');
            evid = orid;
        end
        etype0 = dbgetv(db,'etype');

        if isempty(etype0)
                etype = char(ones(numorigins,1)*'R');
        else
            % convert etypes
            % AVO codes are A, B, C, E, G, L, O, R, X, a, b, h, i, x and
            % '-' = the null etype in Antelope
            % AVO Classification Codes
            % 'a' = Volcano-Tectonic (VT)
            % 'b' = Low-Frequency (LF)
            % 'h' = Hybrid
            % 'E' = Regional-Tectonic
            % 'T' = Teleseismic
            % 'i' = Shore-Ice
            % 'C' = Calibrations
            % 'o' = Other non-seismic
            % 'x' = Cause unknown
            % But AVO catalog also contains A, B, G, L, O, R, X
            % Assuming A, B, O and X are same as a, b, o and x, that still
            % leaves G, L and R

            etype0=char(etype0);
            etype(etype0=='a')='t';
            etype(etype0=='A')='t';
            etype(etype0=='b')='l';
            etype(etype0=='B')='l';
            etype(etype0=='-')='u';
            etype(etype0==' ')='u';
            etype(etype0=='E')='R';
            etype(etype0=='T')='D';
            etype(etype0=='x')='u';
            etype(etype0=='X')='u';
            etype(etype0=='O')='o';
            
        end
        etype = char(etype); % sometimes etype gets converted to ASCII numbers

        % get mag
        mag = max([ml mb ms], [], 2);

        % convert time from epoch to Matlab datenumber
        dnum = epoch2datenum(time);
    end

    % close database
    dbclose(db);
end

function cobj = convert_irisFetch_to_Catalog(ev)
    % Create an Event object for each longitude in the list
    event_list = [];
    for i=1:length(ev) % Loop over each element in vector
        try
            magnitude_obj = [Magnitude(NaN)];
            if ~isnan(ev(i).PreferredMagnitudeValue)
                magnitude_obj = ...
                    Magnitude( ...
                        ev(i).PreferredMagnitude.Value, ...
                        'magnitude_type', ev(i).PreferredMagnitude.Type, ...
                        'public_id', ev(i).PreferredMagnitude.PublicId, ...
                        'comments', [Comment(sprintf('Author=%s',ev(i).PreferredMagnitude.Author))] ...
                    );
            end
            origin_obj = [];
            event_id = 0;
            if ev(i).PreferredTime
                origin_obj = ...
                    Origin( ...
                        datenum(ev(i).PreferredOrigin.Time), ...
                        ev(i).PreferredOrigin.Longitude, ...
                        ev(i).PreferredOrigin.Latitude, ...
                        ev(i).PreferredOrigin.Depth, ...
                        'public_id', ev(i).PreferredOrigin.PublicId, ...
                        'origin_id', ev(i).PreferredOrigin.ContributorOriginId ...
                    );
                event_id = ev(i).PreferredOrigin.ContributorEventId;
            end
            if event_id
                event_list = ...
                    [event_list ...
                        Event( ...
                            [origin_obj], ...
                            'event_type', ev(i).Type, ...
                            'magnitudes', [magnitude_obj],  ...
                            'public_id', ev(i).PublicId, ...
                            'event_id', ev(i).PreferredOrigin.ContributorEventId ...
                        );
                    ];
            else
                 event_list = ...
                    [event_list ...
                        Event( ...
                            [origin_obj], ...
                            'event_type', ev(i).Type, ...
                            'magnitudes', [magnitude_obj],  ...
                            'public_id', ev(i).PublicId ...
                        );
                    ];               
            end
            
        catch ME
            ev(i)
            rethrow(ME);
        end
    end
    
    % CREATE CATALOG OBJECT
    cobj = ...
        Catalog( ...
            event_list, ...
            'description', '', ...
            'comments', [Comment(sprintf('Loaded at %s',datestr(now)))], ...
            'creation_info', CreationInfo('', mfilename, utnow) ...
        ); 
    cobj = cobj.addfield('data_source', 'irisFetch');
end

% function irisFetchExists()
%     if exist('dirisFetch')~=2
%         [st,i]=dbstack();
%         error(sprintf('%s:%s:line %d: irisFetch.m not found\n',st(1).file,st(1).name,st(1).line));
%     end
% end

%% LOAD_AEF
function cobj = load_aef(varargin)     
    % LOAD_AEF
    %   Wrapper for loading dat files generated from Seisan S-FILES (REA) databases.
    %   DAT file name is like YYYYMM.dat
    %   DAT file format is like:
    %   
    %   YYYY MM DD HH MM SS c  MagE
    %
    %   where YYYY MM DD HH MM SS is time in UTC
    %         c is subclass
    %              r = rockfall
    %              e = lp-rockfall
    %              l = long period (lp)
    %              h = hybrid
    %              t = volcano-tectonic
    %              R = regional
    %              u = unknown
    %         MagE is equivalent magnitude, based on energy
    %         produced by the program ampengfft. These values come
    %         from magnitude database that formed part of a
    %         real-time alarm system, but these deleted were
    %         maliciously deleted in June 2003. A magnitude was
    %         computed for each event, assuming a location at sea
    %         level beneath the dome. Regardless of type. This was
    %         particularly helpful for understanding trends in
    %         cumulative energy for different types from week to
    %         week or month to month, and for real-time alarm
    %         messages about pyroclastic flow signals where an
    %         indication of event size was very important.
    %
    %  
  

    % Process input arguments
    p = inputParser;
    p.addParamValue('datapath', '', @isstr);
    p.addParamValue('snum', 0, @isnumeric);  
    p.addParamValue('enum', now, @isnumeric);
    p.addParamValue('minmag', [], @isnumeric);
    p.addParamValue('region', [], @isnumeric);
    p.addParamValue('subclass', '*', @ischar);
    p.addParamValue('mindepth', [], @isnumeric);
    p.addParamValue('maxdepth', [], @isnumeric);
    p.addParamValue('mode', 'normal', @isstr);
    p.parse(varargin{:});
    datapath = p.Results.datapath;
    snum = p.Results.snum;
    enum = p.Results.enum;
    minmag = p.Results.minmag;
    region = p.Results.region;
    mindepth = p.Results.mindepth;
    maxdepth = p.Results.maxdepth;
    if ~exist(datapath, 'dir')
        fprintf('Directory %s not found. Perhaps you need to generate from S files?\n',datapath);
        return;
    end
    
    lnum=snum;

    % loop over all years and months selected
    while (  lnum <= enum ),
        [yyyy, mm] = datevec(lnum);

        % concatenate catalogs
        cobj0 = import_aef_file(datapath,yyyy,mm,snum,enum,p.Results.mode);
        if exist('cobj', 'var')
            cobj = cobj + cobj0;
        else
            cobj = cobj0;
        end
        clear cobj0;
        
        % ready for following month
        lnum=datenum(yyyy,mm+1,1);
    end

    cobj.mag(cobj.mag<-3)=NaN;

    if ~isempty(cobj.dnum)

        % cut data according to threshold mag
        if ~isempty(minmag)
            disp('Applying minimum magnitude filter')
            m = find(cobj.mag > minmag);
            fprintf('Accepting %d events out of %d\n',length(m),length(cobj.dnum));
            cobj.event_list = cobj.event_list(m);
        end    
    end
end
        

        
        
%% IMPORT_AEF_FILE       
function cobj = import_aef_file(dirpath, yyyy, mm, snum, enum, mode)
    cobj = [];
    fprintf('\nAPPEND SEISAN %4d-%02d\n',yyyy,mm)
    datfile = fullfile(dirpath,sprintf('%4d%02d.dat',yyyy,mm));
    if exist(datfile,'file') 
        disp(['loading ',datfile]);
        [yr,mn,dd,hh,mi,ss,etype0,mag0] = textread(datfile,'%d %d %d %d %d %d %s %f');
        dnum = datenum(yr,mn,dd,hh,mi,ss)';
        mag = mag0';
        etype = char(etype0)';
        l = length(dnum);      
        
        if strcmp(mode, 'normal')
            % SLOW MODE
            % Create an Event object for each dnum in the list
            event_list = [];
            for i=1:l % Loop over each element in vector
                if dnum(i)>=snum & dnum(i)<=enum
                    disp(sprintf('%s %5.2f',datestr(dnum(i)), mag(i)))
                    if mag(i) < -3.0
                        mag(i) = NaN;
                    end
                    magnitude_obj = Magnitude(mag(i));
                    origin_obj = Origin(dnum(i), NaN, NaN, NaN, ...
                            'origin_id', sprintf('%4d%02d_%05d',yyyy,mm,i) ...
                        );
                    event_list = [ ...
                        event_list ...
                        Event( ...
                            [origin_obj], ...
                            'event_type', etype(i), ...
                            'magnitudes', [magnitude_obj], ...
                            'event_id', sprintf('%4d%02d_%05d',yyyy,mm,i) ...
                            ) ...
                        ];
                end
            end

            % CREATE CATALOG OBJECT
            cobj = ...
                Catalog( ...
                    event_list, ...
                    'comments', [Comment(sprintf('Loaded at %s',datestr(now)))], ...
                    'creation_info', CreationInfo('', mfilename, utnow) ...
                );
        elseif strcmp(mode, 'fast')
            % FAST MODE
            cobj = Catalog_lite([], [], [], dnum, mag, etype, ...
                    'comments', [Comment(sprintf('Loaded at %s',datestr(now)))], ...
                    'creation_info', CreationInfo('', mfilename, utnow) ...                
                );
        end
        cobj = cobj.addfield('data_source', 'AEF');
        cobj = cobj.addfield('datapath', dirpath);
    else
        disp([datfile,' not found']);
    end

end

