function [mean_m1, b1, sig1, av2] =  bmemag(b);
    %BMEMAG
    newcat = b;
    maximum_mag = max(newcat(:,6));
    minimum_mag = min(newcat(:,6));
    if minimum_mag > 0 ; minimum_mag = 0 ; end

    % calculate the mean magnitude, b(mean) and std
    n = length(newcat(:,6));
    mean_m1 = mean(newcat(:,6));
    b1 = (1/(mean_m1-min(newcat(:,6)-0.05)))*log10(exp(1));
    sig1 = (sum((newcat(:,6)-mean_m1).^2))/(n*(n-1));
    sig1 = sqrt(sig1);
    sig1 = 2.30*sig1*b1^2;            % standard deviation
    %disp ([' b-value segment 1 = ' num2str(b1) ]);
    %disp ([' standard dev b_val_1 = ' num2str(sig1) ]);
    av2 = log10(length(newcat(:,6)))+b1*min(newcat(:,6));
end