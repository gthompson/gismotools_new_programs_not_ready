classdef EventRate
%EventRate Event Rate class constructor.
% 
%    EventRate is a class that has been developed around plotting earthquake
%    counts - i.e. the rate of events per unit time. It has evolved to compute
%    other metrics such the hourly mean event rate, median event rate, mean 
%    magnitude and cumulative magnitude, which are important metrics for an AVO
%    swarm tracking system.
%
%    EventRate can import information from:
%    (1) a Catalog object. 
%    (2) a Datascope database written in the "swarms1.0" schema, defined at AVO. 
%        This is the format used by the swarm tracking system (Thompson &
%        West, 2010).
%
%    ER = EventRate(Catalog_OBJECT, 'binsize', BINSIZE) creates an eventrate object
%    from a Catalog object using non-overlapping bins of BINSIZE days. 
%
%    ER = EventRate(Catalog_OBJECT, 'binsize', BINSIZE, 'stepsize', STEPSIZE) creates an eventrate object
%    using overlapping bins. If omitted STEPSIZE==BINSIZE.
%
%%   EXAMPLES:
%
%       First create a catalog object from the demo database:
%           dbpath = demodb('avo')
%           cobj = readEvents('datascope', 'dbpath', dbpath, ...
%                  'dbeval', ...
%                  'deg2km(distance(lat, lon, 60.4853, -152.7431))<15.0' ...
%                  );
%
%       (1) Create an eventrate object using a binsize of 1 day:
%           erobj = eventrate(cobj, 1);
%
%       (2) Create an eventrate object using a binsize of 1 hour:
%           erobj = eventrate(cobj, 1/24);
%
%       (3) Create an eventrate object using a binsize of 1 hour but a stepsize of 5 minutes:
%           erobj = eventrate(cobj, 1/24, 'stepsize', 5/1440);
%
%
%%   PROPERTIES
%
%    For a list of all properties type properties(EventRate)
%
%    dnum                % (array) time of the center of each bin as a DATENUM
%
%    METRICS:
%        counts 		     % (array) number of events in each bin
%        mean_rate           % (array) number of events per hour in each bin
%        median_rate	     % (array) reciprocal of the median time interval between events. Represented as an hourly rate.
%        cum_mag		     % (array) total sum of energy in each bin, represented as a magnitude.
%        mean_mag		     % (array) mean magnitude of events in each bin 
%        median_mag          % (array) median magnitude of events in each bin
%        min_mag             % (array) smallest magnitude in each bin
%
%    SUMMARY DATA:
%        numbins             % (scalar) number of bins used for grouping
%                                events
%        total_counts        % (scalar) sum of counts
%        total_mag           % (scalar) total sum of energy of all cobjs, represented as a magnitude
%
%    METADATA:
%        etype               % event type/classification. 
%        snum                % (scalar) start date/time in DATENUM format
%        enum                % (scalar) end date/time in DATENUM format
%        binsize             % (scalar) bin size in days
%        stepsize            % (scalar) step size in days
%        region              % (4-element vector) [minlon maxlon minlat maxlat]
%        minmag              % (scalar) magnitudes smaller than this were eliminated
%        dbroot              % path to the original data on disk
%        archiveformat       % indicates if the source is a flat file, or
%                              'daily' or 'monthly' volumes
%        auth                % auth of the events
%
%%   METHODS
%
%    For a list of all methods type methods EventRate 
%
%
%%   See also Catalog, Catalog_lite
%
%% AUTHOR: Glenn Thompson

% $Date: 2014-05-06 14:52:40 -0800 (Tue, 06 May 2014) $
% $Revision: 404 $

%% PROPERTIES %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	properties (SetAccess=private)
        counts = []; 		% (array) number of events in each bin
		mean_rate = [];      % (array) number of events per hour in each bin
		median_rate = [];	% (array) reciprocal of the median time interval between events. Represented as an hourly rate.
		cum_mag = [];		% (array) total sum of energy in each bin, represented as a magnitude.
		mean_mag = [];		% (array)   
        median_mag = [];     % (array)
        total_counts = [];   % (scalar) sum of counts
		total_mag = [];      % (scalar) total sum of energy of all cobjs, represented as a magnitude
        dnum = [];           % (array) 	
        numbins = [];        % (scalar)
        min_mag = [];
        etype = '*';
        snum = 0;
        enum = now;
        binsize = 1;
        stepsize = 1;
        misc_fields = {};
        misc_values = {};
    end
    
 %% PUBLIC METHODS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   
	methods
        %% CONSTRUCTOR
        function erobj = EventRate(dnum, mag, binsize, snum, enum, stepsize, etype) 
            p = inputParser;
            p.addRequired('dnum', @isnumeric);
            p.addOptional('mag', [], @isnumeric);
            p.addOptional('binsize', 0, @isnumeric);
            p.addOptional('snum', 0, @isnumeric);
            p.addOptional('enum', 0, @isnumeric);
            p.addOptional('stepsize', 0, @isnumeric);
            p.addOptional('etype', '', @isstr);
            p.parse(dnum, mag, binsize, snum, enum, stepsize, etype);
            dnum = p.Results.dnum;
            mag  = p.Results.mag;
            if isempty(mag)
                mag = ones(size(dnum)) * NaN;
            end
            if size(mag)~=size(dnum)
                error('dnum and mag must be same size')
            end
            binsize = p.Results.binsize;
            stepsize = p.Results.stepsize;
            snum = p.Results.snum;
            enum = p.Results.enum;
            if snum==0
                snum = min(dnum);
            end
            if enum==0
                enum=max(dnum);
            end
            if ~(binsize>0)
                binsize = autobinsize(enum-snum);
            end
            if ~(stepsize>0)
                stepsize = binsize;
            end      
            if (stepsize > binsize)
               disp(sprintf('Invalid value for stepsize (%f days). Cannot be greater than binsize (%f days).',stepsize, binsize));
               return;
            end
            etype = p.Results.etype;
            if isempty(etype)
                etype = char(ones(size(dnum)) * 'x');
            end
            if size(etype)~=size(dnum)
                error('dnum and etype must be same size')
            end                
            etypes = unique(etype);
            for c=1:length(etypes)
                thisetype = etypes(c);
                i = find(etype==thisetype);
                thisdnum = dnum(i);
                thismag  = mag(i);
                
                % meta data properties
                erobj(c).total_counts = length(i);
                erobj(c).etype = thisetype;
                erobj(c).snum = snum;
                erobj(c).enum = enum;
                erobj(c).binsize = binsize;
                erobj(c).stepsize = stepsize;
                
                % bin the time and mag data
                [dnum_bin, counts_per_bin, sum_per_bin, smallest, ...
                    median_per_bin, std_per_bin, median_time_interval] = ...
                    matlab_extensions.bin_irregular(thisdnum, ...
                    magnitude.mag2eng(thismag), ...
                    binsize, snum, enum, stepsize);
                
                erobj(c).numbins = length(dnum_bin);                
                % vector properties
                erobj(c).dnum = dnum_bin;
                erobj(c).counts = counts_per_bin;
%                 erobj(c).cum_mag = magnitude.eng2mag(sum_per_bin);
%                 erobj(c).cum_mag(sum_per_bin==0) = NaN; % replace -Inf values (0 values in sum_per_bin) as they mess up plots
%                 %erobj(c).energy = cumsum(magnitude.mag2eng(obj(c).cum_mag)
                erobj(c).energy = sum_per_bin;
%                 erobj(c).mean_mag = magnitude.eng2mag(sum_per_bin./counts_per_bin); % mean energy as a magnitude
                erobj(c).median_mag = magnitude.eng2mag(median_per_bin); % median energy as a magnitude
%                 erobj(c).mean_rate = counts_per_bin / (24 * binsize);
                erobj(c).median_rate = 1 ./ (median_time_interval * 24);
                erobj(c).min_mag = magnitude.eng2mag(smallest);
%                 erobj(c).total_mag = magnitude.eng2mag(sum(magnitude.mag2eng(mag)));
            end
        end 
        %% GETTERS
        function cum_mag = get.cum_mag(erobj)
            for c=1:length(erobj)
                cum_mag(c) = magnitude.eng2mag(erobj(c).energy);
            end
        end
        function mean_mag = get.mean_mag(erobj)
            for c=1:length(erobj)
                % mean energy as a magnitude
                mean_mag(c) = magnitude.eng2mag(erobj(c).energy./erobj(c).counts);
            end
        end
        function mean_rate = get.mean_rate(erobj)
            for c=1:length(erobj)
                mean_rate(c) = erobj.counts(c) / (24 * erobj(c).binsize);
            end
        end
        function total_mag = get.total_mag(erobj)
            for c=1:length(erobj)
                total_mag(c) = magnitude.eng2mag(sum(erobj(c).energy));
            end
        end
        %% PLOT
        function plot(obj, varargin) 
            %EventRate/plot
            %   Plot metrics of an EventRate object
            %
            %   The following metrics are available:
            %  
            %        counts 		     % number of events in each bin
            %        mean_rate           % number of events per hour in each bin
            %        median_rate	     % reciprocal of the median time interval between events. Represented as an hourly rate.
            %        energy              % total sum of energy in each bin
            %        cum_mag		     % total sum of energy in each bin, represented as a magnitude.
            %        mean_mag		     % mean magnitude of events in each bin 
            %        median_mag          % median magnitude of events in each bin
            %        min_mag             % smallest magnitude in each bin   
            %
            %   erobj.plot() or plot(erobj) will produce a plot of event
            %   counts per unit time. The time unit is given by erobj.binsize
            %   days.
            %   
            %   erobj.plot('metric', list_of_metrics) will plot each metric
            %   requested in list_of_metrics in a separate panel.
            %   list_of_metrics should be a cell array of valid metric
            %   strings. However, it may be a string if only one metric is
            %   requested.
            %
            %   erobj.plot('metric', 'counts') is equivalent to
            %   erobj.plot() and erobj.plot('metric', {'counts'})
            %
            %   erobj.plot('metric', 'mean_rate') is similar, but the
            %   mean_rate is always events per hour, regardless of the
            %   binsize. So if erobj.binsize = 1 (day), counts will be
            %   exactly 24 * mean_rate.
            %
            %   erobj.plot('metric', {'counts';'cum_mag'}) will plot counts
            %   in one panel and the cumulative magnitude per bin in
            %   another panel. 
            %
            %   In general any number of metrics can be given in
            %   list_of_metrics.
            %
            %   If erobj is an array of eventrate structures (e.g. one per
            %   etype), each is plotted on a separate figure]
            
            p = inputParser;
            p.addParamValue('metric', {'counts'}, @(c) iscell(c)||isstr(c));
            p.parse(varargin{:});
            metric = p.Results.metric;
            if ~iscell(metric)
                metric = {metric};
            end

            % plot each etype on a separate figure, each metric as a
            % subplot
            for c = 1 : numel(obj)
                numsubplots = length(metric);
                figure(gcf+1);
                for cc = 1: numsubplots
                    eval(  sprintf('data = obj(c).%s;',metric{cc} ) );
                    % replace -Inf values as they mess up plots
                    data(isnan(data))=NaN;
                    if strfind(metric{cc}, 'mag')
                        cumdata = magnitude.eng2mag(cumsum(magnitude.mag2eng(data)));           
                        subplot(numsubplots,1,cc), [ax, h1, h2] = plotyy(obj(c).dnum, data, obj(c).dnum, cumdata, @bar, @plot );
                    else
                        subplot(numsubplots,1,cc), [ax, h1, h2] = plotyy(obj(c).dnum, data, obj(c).dnum, cumsum(data), @bar, @plot );
                    end
                    datetick(ax(1), 'x','keeplimits');
                    datetick(ax(2), 'x','keeplimits');
%                     ymax = nanmax(matlab_extensions.catmatrices(1, data));
%                     set(gca, 'YLim', [0 ymax]);
                    set(ax(1), 'YLabel', upper(metric{cc}));
                    set(ax(2), 'YLabel', 'Cumulative');
                end
                suptitle(obj(c).etype);
            end
        end

        %% PYTHONPLOT
        function pythonplot(obj)
            obj.plot({'counts';'cum_mag'});
        end
        
        %% HELENAPLOT
        function helenaplot(obj)
            for c=1:length(obj)
                figure(gcf+1);
                [ax, h1, h2] = plotyy(obj(c).dnum, cumsum(obj(c).mag), obj(c).dnum, cumsum(obj(c).energy), @plot, @plot);
                datetick(ax(1), 'x','keeplimits');
                datetick(ax(2), 'x','keeplimits');
                set(ax(1), 'YLabel', 'Cumulative Magnitude');
                set(ax(2), 'YLabel', 'Cumulative Energy');
            end
        end
        
        %% SAUSAGEPLOT
        function sausageplot(obj, bins_to_plot, points, radii)
            %sausageplot
            %    Under development, this function attempts to replicate the
            %    capabilities of sausageplot.xpy written by Glenn Thompson
            %    at AVO.
            p = inputParser;
            p.addRequired('bins_to_plot', @isnumeric);
            p.addOptional('points', [], @isnumeric);
            p.addOptional('radii', [], @isnumeric);
            p.parse(bins_to_plot, points, radii);
            bins_to_plot = p.Results.bins_to_plot;
            points = p.Results.points;
            radii = p.Results.radii;
%             % Page size, dots-per-inch and scale settings
%             fh = figure()
%             if number_of_bins_to_plot > NUMPOINTS
%                 dpi = 6*(number_of_bins_to_plot+1);
%                 axes_width = 0.8 * (NUMPOINTS + 1) / (number_of_bins_to_plot + 1);
%                 axes_height = 0.8;
%             else
%                 dpi = 6*(NUMPOINTS+1);
%                 axes_width = 0.8;
%                 axes_height = 0.8 * (number_of_bins_to_plot + 1) / (NUMPOINTS + 1);
%             end
%             fh.set_dpi(dpi)
%             fh.set_size_inches((10.0,10.0),forward=True)
%             fig2ax1 = fig2.add_axes([0.1, 0.85-axes_height, axes_width, axes_height]);
%             print_pixels(fig2, fig2ax1, number_of_bins_to_plot, NUMPOINTS);
%             colormapname = 'hot_r';
            MAXMAGCOLORBAR = 5.0;
            MINMAGCOLORBAR = 1.0;
            % Marker size configuration
%             SCALEFACTOR = 84.0 / dpi;
%             MAXMARKERSIZE = 43.0 * SCALEFACTOR;
%             MINMARKERSIZE = 4.0 * SCALEFACTOR;
            PTHRESHOLD = 50;
            for c = 1:length(obj)
                % set up weekending list for yticklabels
                binendstr = {};
                for bin_index=-number_of_bins_to_plot-1: 1: 0
                    dstr = datestr(bin_edges(bin_index))
                    binendstr{bin_index} = dstr;
                end
                pointlabels = {};
                for i=1:length(NUMPOINTS)
                    % filter here based on points and radii
                    j = 1:length(obj(c).counts); % replace this
                    counts = obj(c).counts(j);
                    cummag = obj(c).cum_mag(j);
                    prcntile = percentiles(obj(c).counts);
                    pointlabels{i} = sprintf('%s(%d)', point_label{i}, counts(-1));
                    for bin_index=-number_of_bins_to_plot-1: 1: 0
                        y = obj(c).counts(bin_index);
                        magnitude = obj(c).cum_mag(bin_index);
                        p = y2percentile(y,prcntile);
                        if y>0
                            colorVal = scalarMap.to_rgba(magnitude)
                            msize = MINMARKERSIZE + (p-PTHRESHOLD) * (MAXMARKERSIZE - MINMARKERSIZE) / (100-PTHRESHOLD);
                            if msize<MINMARKERSIZE
                                msize=MINMARKERSIZE;
                            end
%                             fig2ax1.plot(i+0.5, w, 's', color=colorVal, markersize=msize, linewidth=0 );
                            scatter(i+0.5, bin_index, msize, y, 's', 'filled')
                            if msize > MAXMARKERSIZE * 0.3
                                text(i+0.5, bin_index, num2str(y))
%                                fig2ax1.text(i+0.5, w, '%d', y, horizontalalignment='center', verticalalignment='center', fontsize = 8 * SCALEFACTOR)
                            end
                        end
                    end
                end

                % Adding xticks, yticks, labels, grid
%                 fig2ax1.set_axisbelow(True) % I think this puts grid and tickmarks below actual data plotted

                % x-axis
%                 fig2ax1.set_xticks(np.arange(.5,NUMVOLCANOES+.5,1))
                set(gca, 'XTick', 0.5:1:NUMPOINTS+0.5);
%                 fig2ax1.set_xlim([-0.5, NUMVOLCANOES+0.5])
                set(gca, 'XLim', [-0.5 numpoints+0.5])
%                 fig2ax1.xaxis.grid(True, linestyle='-', color='gray')
                grid on;
                set(gca, 'XTickLabel', pointlabels)
%                 fig2ax1.xaxis.set_ticks_position('top')
%                 fig2ax1.xaxis.set_label_position('top')
                %plt.setp( fig2ax1.get_xticklabels(), rotation=45, horizontalalignment='left', fontsize=10*SCALEFACTOR )

                % y-axis
%                 fig2ax1.set_yticks(np.arange(-number_of_weeks_to_plot-0.5, 0, 1))
                set(gca, 'YTick', -number_of_bins_to_plot-0.5: 1: 0)
%                 fig2ax1.set_yticklabels(weekending)
                set(gca, 'YTickLabel', binendstr)
%                 fig2ax1.set_ylim([-number_of_weeks_to_plot - 0.5, -0.5])
                set(gca, 'YLim', -number_of_bins_to_plot -0.5 : 1 : -0.5)
%                 plt.setp( fig2ax1.get_yticklabels(), fontsize=10*SCALEFACTOR )
            end
        end


         
        %% IMPORTSWARMDB
        function obj = importswarmdb(obj, dbname, auth, snum, enum)
            % IMPORTSWARMDB
            % Load a swarm database metrics table into an EventRate object
            % eventrate = importswarmdb(erobj, dbname, auth, snum, enum);  
            %
            % INPUT:
            %	dbname		the path of the database (must have a 'metrics' table)
            %	auth		name of the grid to load swarm tracking metrics for
            %	snum,enum	start and end datenumbers (Matlab time format, see 'help datenum')
            %
            % OUTPUT:
            %	obj		an eventrate object
            %
            % Example:
            %	erobj = importswarmdb('/avort/devrun/dbswarm/swarm_metadata', 'RD_lo', datenum(2010, 7, 1), datenum(2010, 7, 14) );

            % Glenn Thompson, 20100714

            % initialize
            obj.dbroot = dbname;
            obj.snum = snum;
            obj.enum = enum;
            obj.auth = auth;

            % check that database exists
            dbtablename = sprintf('%s.metrics',dbname);
            if exist(dbtablename,'file')
                % load the data
                try
                    db = dbopen(dbname, 'r');
                catch me
                    fprintf('Error: Could not open %s for reading',dbname);
                        return;
                end
                db = dblookup_table(db, 'metrics');
                if (dbquery(db, 'dbRECORD_COUNT')==0)
                    fprintf('Error: Could not open %s for reading',dbtablename);
                    return;
                end
                db = dbsubset(db, sprintf('auth ~= /.*%s.*/',auth));
                numrows = dbquery(db,'dbRECORD_COUNT');
                debug.print_debug(sprintf('Got %d rows after auth subset',numrows),2);
                sepoch = datenum2epoch(snum);
                eepoch = datenum2epoch(enum);
                db = dbsubset(db, sprintf('timewindow_starttime >= %f && timewindow_endtime <= %f',sepoch,eepoch));
                numrows = dbquery(db,'dbRECORD_COUNT');
                debug.print_debug(sprintf('Got %d rows after time subset',numrows),2);

                if numrows > 0
                    % Note that metrics are only saved when mean_rate >= 1.
                    % Therefore there will be lots of mean_rate==0 timewindows not in
                    % database.
                    [tempsepoch, tempeepoch, mean_rate, median_rate, mean_mag, cum_mag] = dbgetv(db,'timewindow_starttime', 'timewindow_endtime', 'mean_rate', 'median_rate', 'mean_ml', 'cum_ml');
                    obj.binsize = (tempeepoch(1) - tempsepoch(1))/86400;
                    obj.stepsize = min(tempsepoch(2:end) - tempsepoch(1:end-1))/86400;
                    obj.dnum = snum+obj.stepsize:obj.stepsize:enum;
                    obj.numbins = length(obj.dnum);
                    obj.mean_rate = zeros(obj.numbins, 1);
                    obj.counts = zeros(obj.numbins, 1);
                    obj.median_rate = zeros(obj.numbins, 1);
                    obj.mean_mag = zeros(obj.numbins, 1);
                    obj.cum_mag = zeros(obj.numbins, 1);
                    for c=1:length(tempeepoch)
                        tempenum = epoch2datenum(tempeepoch(c));
                        i = find(obj.dnum == tempenum);
                        obj.mean_rate(i) = mean_rate(c);
                        obj.counts(i) = mean_rate(c) * (obj.binsize * 24);
                        obj.median_rate(i) = median_rate(c); 
                        obj.mean_mag(i) = mean_mag(c);
                        obj.cum_mag(i) = cum_mag(c);
                    end
                end
                dbclose(db);

            else
                % error - table does not exist
                fprintf('Error: %s does not exist',dbtablename);
                return;
            end

            obj.total_counts = sum(obj.counts)*obj.stepsize/obj.binsize;

        end
        
        %% ADDFIELD
        function obj = addfield(obj,fieldname,val)
            %ADDFIELD add fields and values to object(s) 
            %   obj = addfield(obj, fieldname, value)
            %   This function creates a new user defined field, and fills it with the
            %   included value.  If fieldname exists, it will overwrite the existing
            %   value.
            %
            %   Input Arguments
            %       obj: an EventRate object
            %       fieldname: a string name
            %       value: a value to be added for those fields.  Value can be anything
            %
            %   EventRate objects can hold user-defined fields.  To access the contents, 
            %   use EventRate/get.
            %
            %   Example:
            %       % add a field called "TESTFIELD", containing the numbers 1-45
            %       obj = addfield(obj,'TestField',1:45);
            %
            %       % add a cell field called "MISHMOSH"
            %       obj = addfield(obj,'mishmosh',{'hello';'world'});
            %
            %       % see the result
            %       disp(obj) 
            %
            % See also EventRate/set, EventRate/get

            % AUTHOR: Glenn Thompson

            if isa(fieldname,'char')
                mask = strcmp(fieldname, properties(obj));
                if any(mask)
                    obj = obj.set(fieldname, val);
                else
                    mask = strcmp(upper(fieldname),obj.misc_fields);
                    if any(mask)
                        obj = obj.set(fieldname, val);
                    else
                        obj.misc_fields = [obj.misc_fields, upper(fieldname)];
                        obj = obj.set(upper(fieldname), val);
                    end
                end   
            else
                error('%s:addfield:invalidFieldname','fieldname must be a string', class(cobj))
            end

        end

        %% SET
        function obj = set(obj, varargin)
            %SET Set properties for EventRate object(s)
            %   obj = set(obj,'property_name', val, ['property_name2', val2])
            %   SET is one of the two gateway functions of an object, such as EventRate.
            %   Properties that are changed through SET are typechecked and otherwise
            %   scrutinized before being stored within the EventRate object.  This
            %   ensures that the other EventRate methods are all retrieving valid data,
            %   thereby increasing the reliability of the code.
            %
            %   Another strong advantage to using SET and GET to change and retrieve
            %   properties, rather than just assigning them to EventRate object directly,
            %   is that the underlying data structure can change and grow without
            %   harming the code that is written based on the EventRate object.
            %
            %   For a list of valid property names, type:
            %       properties(obj)
            %   
            %   If user-defined fields were added to the EventRate object (ie, through
            %   addField), these fieldnames are also available through set.
            %
            %   Examples:
            %       (1) Change the description property
            %           obj = obj.set('description','hello world');
            %
            %       (2) Add new a field called CLOSEST_STATION with
            %           % the value 'MBLG'
            %           obj = obj.addfield('CLOSEST_STATION','MBLG');
            %
            %           % change the value of the CLOSEST_STATION field
            %           obj = obj.set('CLOSEST_STATION','MBWH');
            %
            %  See also EventRate/get, EventRate/addfield

            Vidx = 1 : numel(varargin);

            while numel(Vidx) >= 2
                prop_name = upper(varargin{Vidx(1)});
                val = varargin{Vidx(2)};
                mask = strcmp(upper(prop_name),upper(properties(obj)));
                if any(mask)
                    mc = metaclass(obj);
                    i = find(mask);
                    prop_name = mc.PropertyList(i).Name;
                    if isempty(mc.PropertyList(i).GetMethod)
                        eval(sprintf('obj.%s=val;',prop_name));
                    else
                        warning('Property %s is a derived property and cannot be set',prop_name);
                    end
                else
                    switch prop_name
                        case obj.misc_fields
                            mask = strcmp(prop_name,obj.misc_fields);
                            obj.misc_values(mask) = {val};
                        otherwise
                            error('%s:set:unknownProperty',...
                                'can''t understand property name : %s', mfilename,prop_name);
                    end
                end
                Vidx(1:2) = []; %done with those parameters, move to the next ones...
            end 
        end     
        
        %% GET
        function val = get(obj,prop_name)
            %GET Get EventRate properties
            %   val = get(EventRate_object,'property_name')
            %
            %   To see valid property names, type:
            %       properties(EventRate_object)
            %
            %       If additional fields were added to EventRate using ADDFIELD, then
            %       values from these can be retrieved using the fieldname
            %
            %   See also EventRate/SET, EventRate/ADDFIELD, Catalog/GET

            mask = strcmp(prop_name, properties(obj));
            if any(mask)
                eval(sprintf('val=obj.%s;',prop_name));
            else
                mask = strcmp(upper(prop_name),obj.misc_fields);
                if any(mask)
                    val = obj.misc_values{mask};
                else
                    warning('%s:get:unrecognizedProperty',...
                        'Unrecognized property name : %s',  class(obj), prop_name);
                end
            end
        end

    
    end % methods 
    methods (Access=private)    
        %% PERCENTILES
        function p=percentiles(vals)
            l=length(vals);
            for i=1:100
                p(i) = vals(floor(i/100 * l));
            end
        end
        
        %% PLOT_PERCENTILES
        function plot_percentiles(p)
            figure(gcf+1)
            plot(1:100, p);
        end
    end
end
