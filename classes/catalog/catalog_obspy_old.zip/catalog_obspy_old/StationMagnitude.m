classdef StationMagnitude
    % StationMagnitude
    % see http://docs.obspy.org/packages/autogen/obspy.core.event.StationMagnitude.html
    properties
        mag;
%        mag_errors;
        station_magnitude_type;
        amplitude; % Amplitude
%        method;
        scnl;
        comments;
        creation_info;
    end
    methods
        function obj = StationMagnitude(mag, varargin);
            % Parse required, optional and param-value pair arguments,
            % set default values, and add validation conditions
            p = inputParser;
            p.addRequired('mag', @(m) (m>-3 & m<10) | isnan(m));
            p.addOptional('station_magnitude_type', '', @isstr);
            p.addOptional('amplitude', [], @(a) strcmp(class(a), 'Amplitude')  | isempty(c));
            p.addOptional('scnl', '', @(s) strcmp(class(s), 'scnlobject') | isempty(s));
            p.addOptional('comments', [Comment('')], @(c) strcmp(class(c), 'Comment')  | isempty(c));
            p.addOptional('creation_info', CreationInfo(), @(c) strcmp(class(c), 'CreationInfo')  | isempty(c))
            p.parse(mag, varargin{:});
            obj.mag = p.Results.mag;
            obj.station_magnitude_type = p.Results.station_magnitude_type;
            obj.amplitude = p.Results.amplitude;
            obj.scnl = p.Results.scnl;
            obj.comments = p.Results.comments;
            obj.creation_info = p.Results.creation_info;
        end
        function print(obj)
        end
    end
end