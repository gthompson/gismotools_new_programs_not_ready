classdef EventDescription
    % EventDescription
    properties
        text = '';
        type = '';
    end
    methods
        function obj = EventDescription(text, type)
            obj.text = text;
            obj.type = type;
        end
        function str = print(obj)
            str = sprintf('EventDescription:\n\ttext=%s\n\ttype=%s\n', obj.text, obj.type); 
        end
    end
end