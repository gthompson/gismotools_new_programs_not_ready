classdef Origin
%ORIGIN: A class that serves as a container for ORIGIN and other objects.
% 
% This class represents the focal time and geographical location of an 
% earthquake hypocenter, as well as additional meta-information. Origin can
% have objects of type OriginUncertainty and Arrival as child elements. 
%
% Origin is modelled after the ObsPy Origin class:
%   http://docs.obspy.org/packages/autogen/obspy.core.event.Origin.html
%
%% USAGE
%   o = Origin(time, longitude, latitude, depth)
%      creates an Origin object with the time and co-ordinates specified.
%
%% EXAMPLE
%
%   % create an Origin object
%   lat = 62.5; lon = -120.0; depth = 15.2; time = now;
%   o = Origin(time, lon, lat, depth);
%                 
% 
%% See also CATALOG, EVENT, EVENTRATE, READEVENTS, CATALOG_COOKBOOK
%
% Author: Glenn Thompson (glennthompson1971@gmail.com)
% $Date: $
% $Revision: $  
    % Origin
    % see http://docs.obspy.org/packages/autogen/obspy.core.event.Origin.html
    properties
        time; % origin time as datenum
%        time_errors; % seconds
        longitude;
%        longitude_errors;
        latitude;
%        latitude_errors;
        depth;
%        depth_errors;
%        depth_type;
%        time_fixed; %false;
%        epicenter_fixed; %false;
%        method;
%        earth_model;
%        arrivals; % [Arrival() ...]
%        composite_times; % [];
%        quality = '';
        origin_type; % 'hypocenter', 'amplitude' 
%        origin_uncertainty;  [OriginQuality ...]
%        region; % '';
        evaluation_mode; % '', 'manual', 'automatic'
        evaluation_status; % '', 'preliminary', 'confirmed', 'reviewed', 'final', 'reported'
        comments; % [Comment() ...]
        creation_info; % [CreationInfo() ...];
        public_id;
        origin_id;
    end
    methods
        function obj = Origin(time, longitude, latitude, depth, varargin)
            % Parse required, optional and param-value pair arguments,
            % set default values, and add validation conditions
            persistent origin_id;
            if isempty(origin_id)
                origin_id = 1;
            else
                origin_id = origin_id + 1;
            end  
            p = inputParser;
            p.addRequired('time', @(t) t>0 & t<now+1);
            p.addRequired('longitude', @(x) (x>=-180.0 & x<=180.0) | isnan(x));
            p.addRequired('latitude', @(x) (x>=-90.0 & x<=90.0) | isnan(x));
            p.addRequired('depth', @(x) (x>=-10.0 & x<=7000.0) | isnan(x)); % km?
            p.addParamValue('origin_type', '', @isstr);
            p.addParamValue('evaluation_mode', '', @isstr);
            p.addParamValue('evaluation_status', '', @isstr);
            p.addParamValue('comments', [Comment('')], @(c) strcmp(class(c), 'Comment') );
            p.addParamValue('creation_info', CreationInfo(), @(c) strcmp(class(c), 'CreationInfo') )
            p.addParamValue('public_id', '', @isstr);
            p.addParamValue('origin_id', num2str(origin_id), @isstr);
            p.parse(time, longitude, latitude, depth, varargin{:});
            obj.time = time;
            obj.longitude = longitude;
            obj.latitude = latitude;
            obj.depth = depth;
            %obj.method = method;
            %obj.arrivals = p.Results.arrivals;
            obj.origin_type = p.Results.origin_type;
            obj.evaluation_mode = p.Results.evaluation_mode;
            obj.evaluation_status = p.Results.evaluation_status;
            obj.comments = p.Results.comments;
            obj.creation_info = p.Results.creation_info;
            obj.public_id = p.Results.public_id;
            obj.origin_id = p.Results.origin_id;
        end
        function print(obj)
        end
    end
end