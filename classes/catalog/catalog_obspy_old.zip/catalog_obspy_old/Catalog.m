classdef Catalog < Catalog_base
%CATALOG: A class that serves as a container for EVENT objects.
% 
% Catalog is modelled after the ObsPy Catalog class:
%   http://docs.obspy.org/packages/autogen/obspy.core.event.Catalog.html
%
%% USAGE
%   cobj = Catalog(event_list)
%      where event_list is a vector of Event objects.
%
%% EXAMPLE
%
%   % create an Origin object
%   lat = 62.5; lon = -120.0; depth = 15.2; time = now;
%   o = Origin(time, lon, lat, depth);
%   
%   % create an Event object
%   e = Event([o]); % [o] is a vector of Origin objects
%
%   % create a Catalog object
%   c = Catalog([e]); % [e] is a vector of Event objects
%
%   This is a trivial example with only 1 origin and 1 event. In general,
%   a Catalog contains multiple Event objects, and each Event object may
%   contain multiple Origin objects. 
%                 
% 
%% See also EVENT, ORIGIN, EVENTRATE, READEVENTS, CATALOG_COOKBOOK
%
% Author: Glenn Thompson (glennthompson1971@gmail.com)
% $Date: $
% $Revision: $  

    properties(GetAccess = 'public', SetAccess = 'private')
        event_list;
        % derived properties
        % I set these private properties so that I can define get.property
        % functions to get these from event_list.origins
        % These cannot be defined in Catalog_base as could not then define
        % getters for them in Catalog
        lat;
        lon;
        depth;
        time;
        mag;
        etype;
    end
    methods
        function obj = Catalog(event_list, varargin)
            % Parse required, optional and param-value pair arguments,
            % set default values, and add validation conditions
            p = inputParser;
            p.addRequired('event_list', @(e) strcmp(class(e), 'Event') | isempty(e));
            p.addParamValue('description', '', @isstr);
            p.addParamValue('comments', [Comment('')], @(c) strcmp(class(c), 'Comment') );
            p.addParamValue('creation_info', CreationInfo(), @(c) strcmp(class(c), 'CreationInfo')  )
            p.parse(event_list, varargin{:});
            fields = fieldnames(p.Results);
            for i=1:length(fields)
                field=fields{i};
                val = eval(sprintf('p.Results.%s',field));
                obj = obj.set(field, val);
            end
        end
        
        %% THE FOLLOWING METHODS POPULATE PRIVATE PROPERTIES FOR 
        %  ETYPE, LAT, LON, DEPTH, TIME, DNUM, SNUM, ENUM
        %  THESE PROVIDE COMPATIBILITY BETWEEN NEW AND OLD VERSIONS OF
        %  THE CATALOG CLASS
        function etype = get.etype(obj)
            etype = [obj.event_list.event_type];
        end
        function l = get.lat(obj)
            o = origins(obj);
            l = [o.latitude];
        end
        function l = get.lon(obj)
            o = origins(obj);
            l = [o.longitude];
        end            
        function z = get.depth(obj)
            o = origins(obj);
            z = [o.depth];
        end 
        function t = get.time(obj)
            o = origins(obj);
            t = [o.time];
        end
        function m = get.mag(obj)
            m_list = [obj.event_list.magnitudes];
            m = [m_list.mag];
        end

        function cobj = plus(cobj1, cobj2)
            cobj = [];

            if nargin<2
                return
            end
            
            if isempty(cobj1)
                cobj = cobj2;
                return
            end
            
            if isempty(cobj2)
                cobj = cobj1;
                return
            end 

            if isempty(cobj1.event_list) & isempty(cobj2.event_list)
                return
            end

            if isempty(cobj1.event_list)
                cobj = cobj2;  
            elseif isempty(cobj2.event_list)
                cobj = cobj1;
            else
                cobj = cobj1; 
                cobj.event_list = [cobj1.event_list cobj2.event_list];
                return
            end
        end
        
    end
    %%
    methods (Access=protected, Hidden=true)
        
        function o = origins(obj)
            % assumes only 1 origin per event
            % ignores concept of preferred origin
            o = [obj.event_list.origins];
        end   
        
    end
end