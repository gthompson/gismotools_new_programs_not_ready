classdef Event
%EVENT: A class that serves as a container for ORIGIN and other objects.
% 
% The class Event describes a seismic event which does not necessarily need 
% to be a tectonic earthquake. An event is usually associated with one or 
% more origins, which contain information about focal time and geographical
% location of the event. Multiple origins can cover automatic and manual 
% locations, a set of location from different agencies, locations generated
% with different location programs and earth models, etc. Furthermore, an 
% event is usually associated with one or more magnitudes, and with one or
% more focal mechanism determinations.

% Event is modelled after the ObsPy Event class:
%   http://docs.obspy.org/packages/autogen/obspy.core.event.Event.html
%
%% USAGE
%   e = Event([Origin1 Origin2 Origin3])
%      creates an Event object with 3 Origin objects
%
%% EXAMPLE
%
%   % create an Origin object
%   lat = 62.5; lon = -120.0; depth = 15.2; time = now;
%   o1 = Origin(time, lon, lat, depth);
%
%   % create a 2nd Origin object
%   lat = 62.4; lon = -119.87; depth = 12.8; time = now-1/86400;
%   o2 = Origin(time, lon, lat, depth);
%   
%   % create an Event object
%   e = Event([o1 o2]);  
%                 
% 
%% See also CATALOG, ORIGIN, EVENTRATE, READEVENTS, CATALOG_COOKBOOK
%
% Author: Glenn Thompson (glennthompson1971@gmail.com)
% $Date: $
% $Revision: $  

    properties
        origins; %[Origin()];
        event_type;
        magnitudes; %[Magnitude()];
        %event_type_certainty; %'suspected'; % or 'known'
        creation_info;
        %event_descriptions; %[EventDescription()];
        comments; % [Comment() ...]
        %picks; %[Pick()];
        %amplitudes; %[Amplitude()];
        %focal_mechanisms; %[FocalMechanism()];
        public_id;
        event_id;
    end
    methods
        function obj = Event(origins, varargin)
            % Parse required, optional and param-value pair arguments,
            % set default values, and add validation conditions
            persistent event_id;
            if isempty(event_id)
                event_id = 1;
            else
                event_id = event_id + 1;
            end  
            p = inputParser;
            p.addRequired('origins', @(o) strcmp(class(o), 'Origin'));
            p.addParamValue('event_type', '', @isstr);
            p.addParamValue('magnitudes', [Magnitude(NaN)], @(m) strcmp(class(m), 'Magnitude'));
            p.addParamValue('comments', [Comment('')], @(c) strcmp(class(c), 'Comment'));
            p.addParamValue('creation_info', CreationInfo(), @(c) strcmp(class(c), 'CreationInfo'))
            p.addParamValue('public_id', '', @isstr);
            p.addParamValue('event_id', num2str(event_id), @isstr);
            p.parse(origins, varargin{:});
            obj.origins = p.Results.origins;
            obj.event_type = p.Results.event_type;
            obj.magnitudes = p.Results.magnitudes;
            obj.comments = p.Results.comments;
            obj.creation_info = p.Results.creation_info;
            obj.public_id = p.Results.public_id;
            obj.event_id = p.Results.event_id;
        end
        function preferred_focal_mechanism(obj)
        end
        function preferred_magnitude(obj)
        end
        function preferred_origin(obj)
        end
        function print(obj)
        end
    end
end
            
    