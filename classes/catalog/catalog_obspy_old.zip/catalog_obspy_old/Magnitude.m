classdef Magnitude
    % Magnitude
    % see http://docs.obspy.org/packages/autogen/obspy.core.event.Magnitude.html
    properties
        mag;
%        mag_errors;
        magnitude_type;
%        method;
        station_count;
%        azimuthal_gap;
        evaluation_mode;
        evaluation_status;
%        station_magnitudes; %[StationMagnitude()...]
        comments;
        creation_info;
        public_id;
        mag_id;
    end
    methods
        function obj = Magnitude(mag, varargin);
            % Parse required, optional and param-value pair arguments,
            % set default values, and add validation conditions
            persistent mag_id;
            if isempty(mag_id)
                mag_id = 1;
            else
                mag_id = mag_id + 1;
            end  
            p = inputParser;
            if mag==-999 % deal with Antelope NULL value
                mag=NaN;
            end
            p.addRequired('mag', @(m) (m>-3 & m<10) | isnan(m));
            p.addParamValue('magnitude_type', '', @isstr);
            p.addParamValue('station_count', NaN, @(i) floor(i)==i);
            p.addParamValue('evaluation_mode', '', @isstr);
            p.addParamValue('evaluation_status', '', @isstr);
            p.addParamValue('comments', [Comment('')], @(c) strcmp(class(c), 'Comment') );
            p.addParamValue('creation_info', CreationInfo(), @(c) strcmp(class(c), 'CreationInfo') );
            p.addParamValue('public_id', '', @isstr);
            p.addParamValue('mag_id', num2str(mag_id), @isstr);
            try
                p.parse(mag, varargin{:});
            catch
                disp(mag)
            end
            obj.mag = p.Results.mag;
            obj.magnitude_type = p.Results.magnitude_type;
            obj.evaluation_mode = p.Results.evaluation_mode;
            obj.evaluation_status = p.Results.evaluation_status;
            obj.comments = p.Results.comments;
            obj.creation_info = p.Results.creation_info;
            obj.public_id = p.Results.public_id;
            obj.mag_id = p.Results.mag_id;            
        end
        function print(obj)
        end
    end
end