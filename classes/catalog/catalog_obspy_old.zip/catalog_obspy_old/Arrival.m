classdef Arrival
    % Arrival
    % see http://docs.obspy.org/packages/autogen/obspy.core.event.Arrival.html
    properties
        arrival_id;
        pick_id;
        phase;
        time_correction;
        azimuth;
        distance;
        takeoff_angle;
        takeoff_angle_errors;
        time_residual;
        horizontal_slowness_residual;
        backazimuth_residual;
        time_weight;
        horizontal_slowness_weight;
        backazimuth_weight;
        earth_model;
        comments = [];
        creation_info;
    end
    methods
        function obj = Arrival(arrival_id, pick_id, phase, time_correction, azimuth, distance, takeoff_angle);
            obj.arrival_id = arrival_id;
            obj.pick_id = pick_id;
            obj.phase = phase;
            obj.time_correction = time_correction;
            obj.azimuth = azimuth;
            obj.distance = distance;
            obj.takeoff_angle = takeoff_angle;
        end
        function print(obj)
        end
    end
end