classdef OriginQuality
    % OriginQuality
    % see http://docs.obspy.org/packages/autogen/obspy.core.event.OriginQuality.html
    properties
        associated_phase_count;
        used_phase_count;
        associated_station_count;
        used_station_count;
        depth_phase_count;
        standard_error;
        azimuthal_gap;
        secondary_azimuthal_gap;
        ground_truth_level;
        minimum_distance;
        maximum_distance;
        median_distance;
    end
    methods
        function obj = OriginQuality(associated_phase_count, used_phase_count, ...
                standard_error, azimuthal_gap);
            obj.associated_phase_count = associated_phase_count;
            obj.used_phase_count = used_phase_count;
            obj.standard_error = standard_error;
            obj.azimuthal_gap = azimuthal_gap;
        end
        function print(obj)
        end
    end
end