classdef Comment
    % Comment
    properties
        text = '';
        creation_info = CreationInfo();
    end
    methods
        function obj = Comment(text, varargin)
            p = inputParser;
            p.addRequired('text', @isstr);
            p.addOptional('creation_info', obj.creation_info, @(c) strcmp(class(c), 'CreationInfo'));
            p.parse(text, varargin{:})
            obj.text = p.Results.text;
            obj.creation_info= p.Results.creation_info;
        end
        function print(obj)
            disp(sprintf('CreationInfo:\n\ttext=%s\n\ttype=%s\n', obj.text, obj.type)); 
        end
        
    end
end