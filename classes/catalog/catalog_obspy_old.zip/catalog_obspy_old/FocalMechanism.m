classdef FocalMechanism
    % FocalMechanism
    % see http://docs.obspy.org/packages/autogen/obspy.core.event.FocalMechanism.html
    properties
        focalmechanism_id;
        orid;
        nodal_planes;
        pricipal_axes;
        azimuthal_gap;
        station_polarity_count;
        misfit;
        station_distribution_ratio;
        method;
        scnl; % scnlobject
        evaluation_mode = ''; % 'manual', 'automatic'
        evaluation_status = ''; % 'preliminary', 'confirmed', 'reviewed', 'final', 'reported'
        moment_tensor;
        comments = []; % list of Comment
        creation_info = CreationInfo();
    end
    methods
        function obj = FocalMechanism(focalmechanism_id, orid, azimuthal_gap, ...
                scnl, evaluation_mode, evaluation_status);
            obj.focalmechanism_id = focalmechanism_id;
            obj.orid = orid;
            obj.azimuthal_gap = azimuthal_gap;
            obj.scnl = scnl;
            obj.evaluation_mode = evaluation_mode;
            obj.evaluation_status = evaluation_status;
        end
        function print(obj)
        end
    end
end