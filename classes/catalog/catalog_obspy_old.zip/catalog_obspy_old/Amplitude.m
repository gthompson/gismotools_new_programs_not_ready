classdef Amplitude
    % Amplitude
    % see http://docs.obspy.org/packages/autogen/obspy.core.event.Amplitude.html
    properties
        generic_amplitude;
        %generic_amplitude_errors;
        %type;
        %category; 
        unit;
        %method_id;
        %period;
        %snr;
        %time_window;
        %pick_id;
        %waveform_id;
        %filter_id;
        %scaling_time;
        %scaling_time_errors;
        %magnitude_hint;
        %evaluation_mode;
        %evaluation_status;
        comments;
        creation_info;
    end
    methods
        function obj = Amplitude(generic_amplitude, unit, varargin);
            % Parse required, optional and param-value pair arguments,
            % set default values, and add validation conditions
            p = inputParser;
            p.addRequired('generic_amplitude', @isnumeric);
            p.addRequired('unit', @isstr);
            p.addParamValue('comments', [Comment('')], @(c) strcmp(class(c), 'Comment')  | isempty(c));
            p.addParamValue('creation_info', CreationInfo(), @(c) strcmp(class(c), 'CreationInfo')  | isempty(c))
            p.parse(generic_amplitude, unit, varargin{:});
            obj.generic_amplitude = p.Results.generic_amplitude;
            obj.unit = p.Results.unit;
            obj.comments = p.Results.comments;
            obj.creation_info = p.Results.creation_info;
        end
        function print(obj)
        end
    end
end